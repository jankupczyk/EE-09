<?php
$conn = mysqli_connect(
    'localhost',
    'root',
    '',
    'egzamin5'
);
?>











<!-- Jan Kupczyk -->