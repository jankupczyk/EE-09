<?php
$conn = mysqli_connect(
    'localhost',
    'root',
    '',
    'egzamintest'
    );
?>










































<!-- Jan Kupczyk -->