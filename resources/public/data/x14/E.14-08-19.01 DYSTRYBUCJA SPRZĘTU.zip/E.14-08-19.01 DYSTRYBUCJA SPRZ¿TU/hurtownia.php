<!DOCTYPE html>
<html lang="pl-PL">

<head>
	<meta charset="utf-8">
	<meta content="width=device-width, initial-scale=1.0" name="viewport">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

	<title>Hurtownia komputerowa</title>

	<link rel="stylesheet" href="styl2.css">
</head>

<body>
	<div class="list">
		<ul>
			<li>Producenci
				<ol>
					<li>Intel</li>
					<li>AMD</li>
					<li>Motorola</li>
					<li>Corsair</li>
					<li>ADATA</li>
					<li>WD</li>
					<li>Kingstone</li>
					<li>Patriot</li>
					<li>Asus</li>
				</ol>
			</li>
		</ul>
	</div>
	<div class="main-form">
		<h1>Dystrybucja sprzętu komputerowego</h1>
		<form action="hurtownia.php" method="post">
			<input type="number" name="prod">
			<input type="submit" value="WYŚWIETL">
		</form>
	</div>
	<div class="main-logo">
		<img src="sprzet.png" alt="Sprzedajemy komputery">
	</div>
	<div class="main">
		<h1>Podzespoły wybranego producenta: </h1>
		<?php
		$conn = mysqli_connect('localhost', 'root', '', 'sklep');
		if (!isset($_POST["prod"]))
			echo "Wybierz producenta";
		else {
			$prod = $_POST['prod'];

			$sql = "SELECT nazwa, dostepnosc, cena FROM podzespoly WHERE producenci_id = $prod";
			$query = mysqli_query($conn, $sql);
			while ($linia = mysqli_fetch_assoc($query)) {
				if ($linia['dostepnosc'] == 1) {
					echo "<p>" . $linia['nazwa'] . " " . "CENA:" . $linia['cena'] . " DOSTĘPNY" . "</p>";
				} else {
					echo "<p>" . $linia['nazwa'] . " " . "CENA:" . $linia['cena'] . " NIEDOSTĘPNY" . "</p>";
				}
			}
		}
		mysqli_close($conn)
		?>
	</div>
	<div class="footer">
		<h3>Zapraszamy od poniedziałku do soboty w godzinach 7<sup>00</sup>-16<sup>30</sup></h3>
		Strony partnerów: 
		<a href="https://www.adata.com/pl/" target="_blank">ADATA</a>

		<a href="https://www.patriotmemory.com/" target="_blank">Patriot</a>

		<a href="mailto:biuro@hurt.pl">Napisz!</a>

		<p>Stronę wykonał: Jan Kupczyk</p>
	</div>
</body>

</html>

<!-- Jan Kupczyk -->