<!DOCTYPE html>
<html lang="pl-PL">

<head>
	<meta charset="utf-8">
	<meta content="width=device-width, initial-scale=1.0" name="viewport">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

	<title>Podróże dalekie i bliskie</title>

	<link rel="stylesheet" href="styl6.css">
</head>

<body>
	<div class="header">
		<h1>Biuro podróży: WESOŁA WYPRAWA</h1>
	</div>
	<div class="cookie-olg">
		<?php
		if (!isset($_COOKIE["cookie"])) {
			setcookie("cookie", 1, time() + (60 * 60));
			echo "<p>Witaj! Nasza strona używa ciasteczek!</p>";
		} else {
			echo "<p>Witaj ponownie na naszej stronie</p>";
		}
		?>
	</div>
	<div class="miejsca">
		<table>
			<tr>
				<td><img src="polska.jpg" alt="zwiedzanie Krakowa"></td>
				<td><img src="wlochy.jpg" alt="Wenecja i nie tylko"></td>
			</tr>
			<tr>
				<td><img src="grecja.jpg" alt="gorące Greckie wyspy"></td>
				<td><img src="hiszpania.jpg" alt="Słoneczna Barcelona"></td>
			</tr>
		</table>
	</div>
	<div class="wycieczki">
		<h3>Proponujemy wycieczki</h3>
		<ul>
			<li>autokarowe
				<ol>
					<li>po Polsce z przewodnikiem</li>
					<li>do Niemiec i Czech</li>
				</ol>
			</li>
			<li>samolotem
				<ol>
					<li>wczasy w Grecji</li>
					<li>zwiedzanie Barcelony</li>
					<li>zwiedzanie Wenecji</li>
				</ol>
			</li>
		</ul>
		<h3>Pobierz dokumenty</h3>
		<p><a href="Regulamin.txt">Regulamin korzystania z usług biura podróży</a></p>
		<p><a href="galeria.pl" target="_blank">Tu znajdziesz zdjęcia z naszych wycieczek</a></p>
	</div>
	<div class="footer">
		Stronę przygotował: Jan Kupczyk

	</div>
</body>

</html>


<!-- Jan Kupczyk -->