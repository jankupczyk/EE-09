<?php
$conn = mysqli_connect(
    'localhost',
    'root',
    '',
    'baza'
);
?>

<!-- Jan Kupczyk 4TID -->